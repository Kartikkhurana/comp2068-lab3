sys  = require 'sys'
http = require 'http'
host = "0.0.0.0"
port = 3000

var readline = require('readline-sync');

var num = readline.question("Enter a number\n");
var num2 = readline.question("Ente another number\n");
var op = readline.question("Choose an operation (+,-,/,*)\n");
var result;
switch (op) {
case '+':
result = parseFloat(num) + parseFloat(num2);
break;
case '-':
result = parseFloat(num) - parseFloat(num2);
break;
case '*':
result = parseFloat(num) * parseFloat(num2);
break;
case '/':
result = parseFloat(num) / parseFloat(num2);
break;
}

console.log( num + " " + op + " " + num2 + " = " + result);
