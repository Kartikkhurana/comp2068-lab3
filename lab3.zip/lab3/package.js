"name": "calculator",
 "version": "0.0.0",
 "description": "creating a calculator",
 "main": "index.js",
 "scripts": {
   "test": "echo "Error: no test specified" && exit 1"
 },
